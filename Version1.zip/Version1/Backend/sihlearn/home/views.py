from django.shortcuts import render,HttpResponse


def index(request):
    return render(request,'index.html')

def login(request):
    return render(request,'login.html')

def signup(request):
    return render(request,'Reg.html')
# Create your views here.

def faq(request):
    return render(request,'faq.html')